import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { GUI } from "dat.gui";
import * as Tone from "tone";
import { Noise } from "noisejs";
import "./styles.css";

let scene, camera, renderer;
let geometry, material, cube;
let nGeometry, blueMaterial, nCube;
let colour, intensity, light;
let ambientLight;
let sceneHeight, sceneWidth;
let numMovers, movers, synths;
let musicalScale;

let orbit;
let params;
let params2;

let listener, sound, audioLoader;

let clock, delta, interval;

let startButton = document.getElementById("startButton");
startButton.addEventListener("click", init);

function init() {
  // remove overlay
  let overlay = document.getElementById("overlay");
  overlay.remove();

  //create our clock and set interval at 30 fpx
  clock = new THREE.Clock();
  delta = 0;
  interval = 1 / 2; //fps

  sceneWidth = window.innerWidth;
  sceneHeight = window.innerHeight;

  // create mover class
  class Mover {
    constructor(x, y, z, offset) {
      this.x = x;
      this.y = y;
      this.z = z;

      this.angle = new THREE.Vector3(0, offset, 0);
      this.velocity = new THREE.Vector3(0.1, 0.01, 0.01);
      this.amplitude = new THREE.Vector3(0.5, 2.5, 0.5);

      this.geo = new THREE.BoxGeometry(0.5, 0.5, 0.5);
      this.mat = new THREE.MeshPhongMaterial({
        color: new THREE.Color(0x2e8b57)
      });

      this.box = new THREE.Mesh(this.geo, this.mat);
      this.box.position.set(this.x, this.y, this.z);
      this.noise = new Noise();
      scene.add(this.box);
    }

    update() {}

    display() {
      this.box.position.set(this.x, this.y, this.z);
    }
  }

  // initiate new variables variables(mover,synths etc)
  numMovers = 18;
  movers = [];
  synths = [];
  musicalScale = [0, 3, 7, 10, 13];

  //create our scene
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0xf5f5f5);
  //create camera
  camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
  );
  camera.position.z = 25;
  camera.position.y = 0;

  //specify our renderer and add it to our document
  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  //create the orbit controls instance so we can use the mouse move around our scene
  orbit = new OrbitControls(camera, renderer.domElement);
  orbit.enableZoom = true;
  orbit.autoRotate = false;

  colour = 0xffffff;
  intensity = 1;
  light = new THREE.DirectionalLight(colour, intensity);
  light.position.set(-1, 2, 4);
  scene.add(light);
  ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
  scene.add(ambientLight);

  // push movers into Array
  for (let i = 0; i < numMovers; i++) {
    movers.push([]);
    for (let j = 0; j < numMovers / 2; j++) {
      movers[i].push(new Mover(i - 10, 0, j - 5, i * 0.25)); // no offset yet
    }
  }

  // gridhelper
  var size = 50;
  var division = 25;
  var mGridHelper = new THREE.GridHelper(size, division, material, material);

  //scene.add(mGridHelper);

  // listeners
  window.addEventListener("resize", onWindowResize, false);
  params = { noize: 1 };
  const gui = new GUI();
  gui.add(params, "noize").min(1.0).max(5.0);
  params2 = { speed: 0.01};
  const gui2 = new GUI();
  gui2.add(params2, "speed").min(0.01).max(0.1);
  

  play();
}

// stop animating (not currently used)
function stop() {
  renderer.setAnimationLoop(null);
}

// simple render function

function render() {
  renderer.render(scene, camera);
  for (let i = 0; i < numMovers; i++) {
    for (let j = 0; j < numMovers / 2; j++) {
      movers[i][j].display();
    }
  }
  renderer.render(scene, camera);
}

// start animating

function play() {
  //using the new setAnimationLoop method which means we are WebXR ready if need be
  renderer.setAnimationLoop(() => {
    update();
    render();
  });
}

//our update function

function update() {
  orbit.update();
  //update stuff in here
  delta += clock.getDelta();

  if (delta > interval) {
    delta = delta % interval;
  }

  for (let i = 0; i < numMovers; i++) {
    let octave = parseInt(i/12,10);
    let freq = 36 + (musicalScale[i%5] + (octave*12));
    synths.push(new Tone.MonoSynth({ 
      oscillator: {
        type: "sawtooth"
      },
      envelope: {
        attack: 0.01
      }   
    }));
    synths[i].toDestination(); //connect our synth to the main output
		synths[i].triggerAttack(Tone.Frequency(freq, "midi")+Math.random(6),0,0.01);
    let boxPosMap = THREE.MathUtils.mapLinear( // map the mover's box position from world coordinates to between -1 and 1
    movers[i][0].box.position.y,
    -movers[i][0].amplitude.y / 10,
    movers[i][0].amplitude.y,
    -1,
    1
  );
  let boxPosMapClamp = THREE.MathUtils.clamp(boxPosMap, 0, 3); // ensure our newly mapped value never goes above 3 or below 0
  let boxPosGainTodB = Tone.gainToDb(boxPosMapClamp); // convert our mapped and constrained value to decibels
  synths[i].volume.linearRampTo(boxPosGainTodB, 0.01);
     
    for (let j = 0; j < numMovers / 2; j++) {
     // movers[i][j].velocity =  
     movers[i][j].velocity.y = params2.speed;
     movers[i][j].angle.add(movers[i][j].velocity);
     
      let perl =
        movers[i][j].noise.perlin2(
          movers[i][j].angle.y,
          movers[i][j].amplitude.y
        ) * params.noize;
      movers[i][j].y =
        Math.sin(movers[i][j].angle.y) * movers[i][j].amplitude.y + perl;
    } 
  }
}

function onWindowResize() {
  //resize & align
  sceneHeight = window.innerHeight;
  sceneWidth = window.innerWidth;
  renderer.setSize(sceneWidth, sceneHeight);
  camera.aspect = sceneWidth / sceneHeight;
  camera.updateProjectionMatrix();
}
